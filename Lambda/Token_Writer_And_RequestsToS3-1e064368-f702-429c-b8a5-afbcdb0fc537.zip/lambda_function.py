import json
import boto3
import requests
from botocore.exceptions import ClientError
from datetime import datetime

# Definimos las variables que usaremos y del secreto que queremos escribir
s3_bucket="bucket-for-requests"
secret_oauth_name="oauth_token_idealista"
file_name='housing_data_2.json'

# Inicializamos clientes de secrets manager y del bucket
s3_client=boto3.client('s3')
secrets_client=boto3.client('secretsmanager')

def get_secret():
    # Definimos los nombres del secreto al que queremos extraer su valor
    secret_name = "api_secret_2"
    region_name = "eu-west-3"
    
    #Inicializamos la sesión
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )
    
    # Intentamos extraer el valor del secreto y guardarlo en una variable.
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    # Manejamos la excepción ClientError.
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print("The requested secret " + secret_name + " was not found")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            print("The request was invalid due to:", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            print("The request had invalid params:", e)
        elif e.response['Error']['Code'] == 'DecryptionFailure':
            print("The requested secret can't be decrypted using the provided KMS key:", e)
        elif e.response['Error']['Code'] == 'InternalServiceError':
            print("An error occurred on service side:", e)
    else:
        # Secrets Manager desencripta el valor del secreto usando las claves maestras de la cuenta. 
        # Dependiendo de si el secreto es una string o un valor binario, solo uno de los dos campos será rellenado.
        if 'SecretString' in get_secret_value_response:
            text_secret_data = json.loads(get_secret_value_response['SecretString'])
            return text_secret_data
        else:
            binary_secret_data = get_secret_value_response['SecretBinary']
            return binary_secret_data

def get_oauth_token():
    # Obtenemos el valor de las credenciales
    api_credentials=get_secret()
    api_secret=api_credentials['Secret']
    
    url="https://api.idealista.com/oauth/token"
    # Cabeceras para la solicitud
    headers={
        "Content-Type":"application/x-www-form-urlencoded",
        "Authorization":api_secret
        
    }
    # Datos a incluir para conseguir el bearer token
    payload={
        "grant_type":"client_credentials",
        "scope":"read"
        
    }
    
    # Hacemos la solicitud para obtener el oauth token
    r=requests.post(url=url, data=payload, headers=headers)
    # Lanzamos el status del error en caso de que la solicitud falle
    r.raise_for_status()
    
    # Convertimos los datos en JSON y accedemos al token, guardándolo para futuro uso.
    token_data=r.json()
    access_token=token_data['access_token']
    
    # Guardamos el token en AWS Secrets Manager
    secrets_client.put_secret_value(
        SecretId=secret_oauth_name,
        SecretString=json.dumps({'access_token':access_token})
    )
    return access_token

def fetch_and_store_data(access_token):
    url="https://api.idealista.com/3.5/es/search"
    headers={
        "Authorization":f"Bearer {access_token}",
        "Content-Type":"application/x-www-form-urlencoded"
    }
    page=1
    for i in range(100):
        payload={
            "center": "40.392152,-3.699759",
            "propertyType": "homes",
            "distance": "20000",
            "operation": "sale",
            "maxItems":"50",
            "numPage":f"{page}"
        }
        
        # Realizamos la solicitud a la API.
        r=requests.post(url, data=payload, headers=headers)
        r.raise_for_status()
        data=r.json()
        save_and_append_to_s3(data)
        page+=1
        
        # Si no hay más elementos en la lista, salimos del bucle.
        if not data.get("elementList"):
            print ("No hay más datos en el archivo.")
            break
            
def save_and_append_to_s3(data):
    # Intentamos leer el archivo en caso de que exista
    try:
        obj=s3_client.get_object(Bucket=s3_bucket, Key="data/api_database/requests_json/bronze/" + file_name)
        existing_data=json.loads(obj['Body'].read().decode('utf-8'))
    except s3_client.exceptions.NoSuchKey:
        existing_data=[]
    
    # Agregamos una nueva entrada 
    existing_data.append(data)
    
    # Escribimos en el bucket
    s3_client.put_object(
        Bucket=s3_bucket,
        Key="data/api_database/requests_json/bronze/" + file_name,
        Body=json.dumps(existing_data)
        )

def lambda_handler(event, context):
    # Intentar obtener el token desde Secrets Manager
    try:
        secret_value = secrets_client.get_secret_value(SecretId=secret_oauth_name)
        token_data = json.loads(secret_value['SecretString'])
        access_token = token_data['access_token']
    except secrets_client.exceptions.ResourceNotFoundException:
        # Si el token no existe, obtener uno nuevo
        access_token = get_oauth_token()
    except Exception as e:
        # Si ocurre cualquier otro error, obtener un nuevo token
        access_token = get_oauth_token()
    
    # Llamar a la API y almacenar los datos en S3
    try:
        fetch_and_store_data(access_token)
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            # Token expirado, obtener uno nuevo y repetir la solicitud
            access_token = get_oauth_token()
            fetch_and_store_data(access_token)
        else:
            raise

    return {
        'statusCode': 200,
        'body': json.dumps('Proceso completado')
    }